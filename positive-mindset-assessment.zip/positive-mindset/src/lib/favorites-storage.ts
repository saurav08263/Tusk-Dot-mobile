import AsyncStorage from '@react-native-async-storage/async-storage';

const FAVORITES_KEY = '@positive-mindset/favorites';

/**
 * Reads the saved favorite ids.
 * Returns [] when nothing is stored yet or the stored value is unreadable.
 */
export async function loadFavoriteIds(): Promise<string[]> {
  try {
    const raw = await AsyncStorage.getItem(FAVORITES_KEY);
    if (!raw) return [];

    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];

    return parsed.filter((id): id is string => typeof id === 'string');
  } catch (error) {
    console.warn('Could not load favorites:', error);
    return [];
  }
}

/** Persists the favorite ids as a JSON array. */
export async function saveFavoriteIds(ids: string[]): Promise<void> {
  try {
    await AsyncStorage.setItem(FAVORITES_KEY, JSON.stringify(ids));
  } catch (error) {
    console.warn('Could not save favorites:', error);
  }
}
