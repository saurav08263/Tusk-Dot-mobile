import affirmationsData from '../data/affirmations.json';
import type { Affirmation, TopicName } from './types';

/** All affirmations, loaded from the local JSON data file (no remote API). */
export const affirmations = affirmationsData as Affirmation[];

export function getAffirmationsForTopic(topic: TopicName): Affirmation[] {
  return affirmations.filter((affirmation) => affirmation.topic === topic);
}

export function findAffirmationById(id: string): Affirmation | undefined {
  return affirmations.find((affirmation) => affirmation.id === id);
}
