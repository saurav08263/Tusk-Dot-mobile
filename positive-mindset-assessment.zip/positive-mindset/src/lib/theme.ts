import { Platform } from 'react-native';

/** Shared design tokens for the whole app. */
export const colors = {
  background: '#F7F2E9',
  surface: '#FFFFFF',
  ink: '#24313C',
  muted: '#7E848B',
  primary: '#2F5D50',
  primarySoft: '#DFEDE4',
  heart: '#E24E4E',
  border: '#ECE5D8',
  onPrimary: '#FFFFFF',
} as const;

/**
 * Platform serif font for headings and quotes.
 * Uses the system serif so no font files need to be bundled.
 */
export const serif = Platform.select({
  ios: 'Georgia',
  android: 'serif',
  default: 'Georgia',
});
