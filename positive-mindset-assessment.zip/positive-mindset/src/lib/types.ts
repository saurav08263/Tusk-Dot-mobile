/** The three topics, using the exact topic names from the data file. */
export type TopicName = 'Confidence' | 'Calm' | 'Motivation';

export interface Affirmation {
  id: string;
  text: string;
  topic: TopicName;
}
