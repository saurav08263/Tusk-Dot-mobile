import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import { affirmations } from '../lib/affirmations';
import { loadFavoriteIds, saveFavoriteIds } from '../lib/favorites-storage';
import type { Affirmation } from '../lib/types';

interface FavoritesContextValue {
  favoriteIds: string[];
  favoriteAffirmations: Affirmation[];
  /** True once stored favorites have been read from AsyncStorage. */
  isLoaded: boolean;
  isFavorite: (id: string) => boolean;
  toggleFavorite: (id: string) => void;
}

const FavoritesContext = createContext<FavoritesContextValue | undefined>(undefined);

/** Ids that actually exist in the data file (guards against stale stored ids). */
const knownIds = new Set(affirmations.map((affirmation) => affirmation.id));

export function FavoritesProvider({ children }: { children: ReactNode }) {
  const [favoriteIds, setFavoriteIds] = useState<string[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  // Load persisted favorites once when the app starts.
  useEffect(() => {
    let isActive = true;

    loadFavoriteIds().then((ids) => {
      if (!isActive) return;
      setFavoriteIds(ids.filter((id) => knownIds.has(id)));
      setIsLoaded(true);
    });

    return () => {
      isActive = false;
    };
  }, []);

  // Persist favorites whenever the list changes (after the initial load).
  useEffect(() => {
    if (isLoaded) void saveFavoriteIds(favoriteIds);
  }, [favoriteIds, isLoaded]);

  const toggleFavorite = useCallback((id: string) => {
    setFavoriteIds((current) =>
      current.includes(id) ? current.filter((value) => value !== id) : [...current, id],
    );
  }, []);

  const value = useMemo<FavoritesContextValue>(() => {
    const favoriteSet = new Set(favoriteIds);
    return {
      favoriteIds,
      favoriteAffirmations: favoriteIds
        .map((id) => affirmations.find((affirmation) => affirmation.id === id))
        .filter((affirmation): affirmation is Affirmation => affirmation !== undefined),
      isLoaded,
      isFavorite: (id: string) => favoriteSet.has(id),
      toggleFavorite,
    };
  }, [favoriteIds, isLoaded, toggleFavorite]);

  return <FavoritesContext.Provider value={value}>{children}</FavoritesContext.Provider>;
}

export function useFavorites(): FavoritesContextValue {
  const context = useContext(FavoritesContext);
  if (!context) {
    throw new Error('useFavorites must be used inside a FavoritesProvider');
  }
  return context;
}
