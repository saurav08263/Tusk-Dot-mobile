import { useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { FadeInView } from '../../components/FadeInView';
import { HeartButton } from '../../components/HeartButton';
import { useFavorites } from '../../context/FavoritesContext';
import { getAffirmationsForTopic } from '../../lib/affirmations';
import { getTopic } from '../../lib/topics';
import { colors, serif } from '../../lib/theme';

export default function AffirmationScreen() {
  const params = useLocalSearchParams<{ topicId: string; id?: string }>();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { isFavorite, toggleFavorite } = useFavorites();

  const topic = getTopic(params.topicId);
  const affirmationsInTopic = useMemo(
    () => (topic ? getAffirmationsForTopic(topic.name) : []),
    [topic],
  );

  // Start on the requested affirmation (used when opening from Favorites), else the first one.
  const [index, setIndex] = useState(() => {
    if (params.id) {
      const found = affirmationsInTopic.findIndex((item) => item.id === params.id);
      if (found >= 0) return found;
    }
    return 0;
  });

  const current = affirmationsInTopic[index];

  const showNext = () => {
    setIndex((value) => (value + 1) % affirmationsInTopic.length);
  };

  // Graceful fallback for an unknown or empty topic.
  if (!topic || !current) {
    return (
      <View style={[styles.screen, styles.center, styles.fallback]}>
        <Text style={styles.fallbackTitle}>Nothing here yet</Text>
        <Text style={styles.fallbackText}>This topic does not have any affirmations.</Text>
        <Pressable
          accessibilityRole="button"
          style={styles.nextButton}
          onPress={() => router.replace('/')}
        >
          <Text style={styles.nextText}>Back to topics</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <LinearGradient colors={topic.gradient} style={StyleSheet.absoluteFill} />

      <View style={[styles.header, { paddingTop: insets.top + 8 }]}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Go back"
          hitSlop={12}
          onPress={() => router.back()}
        >
          <Ionicons name="chevron-back" size={26} color={colors.ink} />
        </Pressable>
        <Text style={styles.headerTitle}>{topic.name}</Text>
        <HeartButton
          active={isFavorite(current.id)}
          onPress={() => toggleFavorite(current.id)}
        />
      </View>

      <View style={styles.quoteArea}>
        <FadeInView animationKey={current.id}>
          <Text style={styles.quote}>“{current.text}”</Text>
          <Text style={styles.quoteId}>{current.id}</Text>
        </FadeInView>
      </View>

      <View style={[styles.footer, { paddingBottom: insets.bottom + 24 }]}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Show next affirmation"
          style={({ pressed }) => [styles.nextButton, pressed && styles.nextPressed]}
          onPress={showNext}
        >
          <Text style={styles.nextText}>Next</Text>
          <Ionicons name="arrow-forward" size={20} color={colors.onPrimary} />
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  center: { alignItems: 'center', justifyContent: 'center' },
  fallback: { backgroundColor: colors.background, padding: 24 },
  fallbackTitle: { fontFamily: serif, fontSize: 22, fontWeight: '700', color: colors.ink },
  fallbackText: { fontSize: 14, color: colors.muted, marginTop: 6, marginBottom: 24 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
  },
  headerTitle: { fontSize: 16, fontWeight: '700', color: colors.ink },
  quoteArea: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 28,
  },
  quote: {
    fontFamily: serif,
    fontSize: 30,
    lineHeight: 42,
    fontWeight: '600',
    color: colors.ink,
    textAlign: 'center',
  },
  quoteId: {
    fontSize: 13,
    letterSpacing: 1,
    color: colors.muted,
    fontWeight: '600',
    textAlign: 'center',
    marginTop: 18,
  },
  footer: { paddingHorizontal: 28 },
  nextButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    height: 56,
    borderRadius: 28,
    backgroundColor: colors.primary,
    shadowColor: '#1D3A31',
    shadowOpacity: 0.25,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 5 },
    elevation: 4,
  },
  nextPressed: { opacity: 0.9, transform: [{ scale: 0.98 }] },
  nextText: { color: colors.onPrimary, fontSize: 17, fontWeight: '700' },
});
