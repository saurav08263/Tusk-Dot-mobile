import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { TopicCard } from '../../components/TopicCard';
import { getAffirmationsForTopic } from '../../lib/affirmations';
import { topics } from '../../lib/topics';
import { colors, serif } from '../../lib/theme';

export default function TopicsScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.screen, { paddingTop: insets.top + 12 }]}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <MaterialCommunityIcons name="sprout" size={40} color={colors.primary} />
        <Text style={styles.title}>Choose a Topic</Text>
        <Text style={styles.subtitle}>Pick a topic that feels right for you today.</Text>
        <View style={styles.cards}>
          {topics.map((topic) => (
            <TopicCard
              key={topic.name}
              topic={topic}
              count={getAffirmationsForTopic(topic.name).length}
              onPress={() => router.push(`/affirmation/${topic.name}`)}
            />
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  content: { padding: 20, paddingBottom: 32 },
  title: {
    fontFamily: serif,
    fontSize: 30,
    lineHeight: 38,
    fontWeight: '700',
    color: colors.ink,
    marginTop: 10,
  },
  subtitle: { fontSize: 15, lineHeight: 21, color: colors.muted, marginBottom: 22 },
  cards: { gap: 14 },
});
