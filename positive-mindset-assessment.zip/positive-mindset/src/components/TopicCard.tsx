import { Pressable, StyleSheet, Text, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import type { Topic } from '../lib/topics';
import { colors } from '../lib/theme';

interface TopicCardProps {
  topic: Topic;
  count: number;
  onPress: () => void;
}

/** Colored card on the home screen that opens a topic. */
export function TopicCard({ topic, count, onPress }: TopicCardProps) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`Open ${topic.name} affirmations`}
      onPress={onPress}
      style={({ pressed }) => [
        styles.card,
        { backgroundColor: topic.cardColor },
        pressed && styles.pressed,
      ]}
    >
      <View style={styles.iconWrap}>
        <MaterialCommunityIcons name={topic.icon} size={26} color={topic.accentColor} />
      </View>
      <View style={styles.textWrap}>
        <Text style={styles.name}>{topic.name}</Text>
        <Text style={styles.tagline}>{topic.tagline}</Text>
        <Text style={styles.count}>
          {count} affirmation{count === 1 ? '' : 's'}
        </Text>
      </View>
      <Ionicons name="arrow-forward" size={20} color={colors.primary} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 20,
    padding: 16,
    gap: 14,
  },
  pressed: { opacity: 0.85, transform: [{ scale: 0.99 }] },
  iconWrap: {
    width: 48,
    height: 48,
    borderRadius: 14,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textWrap: { flex: 1, gap: 2 },
  name: { fontSize: 17, fontWeight: '700', color: colors.ink },
  tagline: { fontSize: 13, lineHeight: 18, color: colors.ink, opacity: 0.75 },
  count: { fontSize: 12, color: colors.muted, marginTop: 2 },
});
