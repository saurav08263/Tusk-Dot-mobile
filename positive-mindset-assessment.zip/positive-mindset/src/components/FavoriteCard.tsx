import { Pressable, StyleSheet, Text, View } from 'react-native';
import type { Affirmation } from '../lib/types';
import { getTopic } from '../lib/topics';
import { colors, serif } from '../lib/theme';
import { HeartButton } from './HeartButton';

interface FavoriteCardProps {
  affirmation: Affirmation;
  onToggleFavorite: () => void;
  onPress: () => void;
}

/** Card shown in the Favorites list for each saved affirmation. */
export function FavoriteCard({ affirmation, onToggleFavorite, onPress }: FavoriteCardProps) {
  const topic = getTopic(affirmation.topic);
  if (!topic) return null;

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`Open ${topic.name} affirmation ${affirmation.id}`}
      onPress={onPress}
      style={({ pressed }) => [styles.card, pressed && styles.pressed]}
    >
      <View style={styles.topRow}>
        <View style={[styles.chip, { backgroundColor: topic.cardColor }]}>
          <Text style={[styles.chipText, { color: topic.accentColor }]}>{topic.name}</Text>
        </View>
        <HeartButton active size={22} onPress={onToggleFavorite} />
      </View>
      <Text style={styles.quote}>“{affirmation.text}”</Text>
      <Text style={styles.id}>{affirmation.id}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderRadius: 18,
    padding: 16,
    gap: 10,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  pressed: { opacity: 0.85 },
  topRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  chip: { borderRadius: 999, paddingVertical: 4, paddingHorizontal: 10 },
  chipText: { fontSize: 12, fontWeight: '700' },
  quote: { fontFamily: serif, fontSize: 16, lineHeight: 23, color: colors.ink },
  id: { fontSize: 12, color: colors.muted, letterSpacing: 0.5 },
});
