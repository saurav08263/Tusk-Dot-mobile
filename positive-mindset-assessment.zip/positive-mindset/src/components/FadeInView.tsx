import { useEffect, useState } from 'react';
import type { ReactNode } from 'react';
import { Animated } from 'react-native';
import type { StyleProp, ViewStyle } from 'react-native';

interface FadeInViewProps {
  /** Change this value to replay the fade (e.g. the affirmation id). */
  animationKey: string;
  style?: StyleProp<ViewStyle>;
  children: ReactNode;
}

/** Small helper that fades its children in whenever `animationKey` changes. */
export function FadeInView({ animationKey, style, children }: FadeInViewProps) {
  const [opacity] = useState(() => new Animated.Value(0));

  useEffect(() => {
    opacity.setValue(0);
    Animated.timing(opacity, {
      toValue: 1,
      duration: 250,
      useNativeDriver: true,
    }).start();
  }, [animationKey, opacity]);

  return <Animated.View style={[style, { opacity }]}>{children}</Animated.View>;
}
