# Positive Mindset

A small affirmations app built for the **Tusk & Dot Mobile Developer Technical Assessment**.

Choose one of three topics — **Confidence**, **Calm**, or **Motivation** — browse affirmations
one at a time, and save the ones you love to **Favorites**. Favorites are persisted locally,
so they are still there when you come back.

Built with **React Native + Expo + TypeScript**. No backend, no remote APIs — all data lives
in a local JSON file and all preferences are stored on-device.

## Features

- **Affirmation screen** — one affirmation at a time with clean typography, a per-topic
  gradient, the affirmation ID, and a subtle fade transition between affirmations.
- **Three topics** — Confidence, Calm, and Motivation, each showing only its own affirmations.
- **Next button** — cycles to the next affirmation within the selected topic (wraps around).
- **Favorites** — add/remove with the heart button; persisted with AsyncStorage so they
  survive closing and reopening the app. Includes a friendly empty state.
- **Settings** — an Appearance section to switch between **Light**, **Dark**, and
  **System** (follows the device setting). The choice is saved with AsyncStorage and
  applied across every screen, including dark per-topic gradients on the affirmation
  screen.
- **Sample data** — the official `Tusk_and_Dot_Mobile_Assessment_Sample_Data.json`
  (30 affirmations: 10 Confidence, 10 Calm, 10 Motivation), included at
  `src/data/affirmations.json` exactly as provided.

## Requirements

- [Node.js](https://nodejs.org/) 18 or newer
- npm, yarn, pnpm, or bun
- To run on a phone: the **[Expo Go](https://expo.dev/go)** app (iOS/Android)
- To run on a simulator: Xcode (macOS) and/or Android Studio

## Getting started

```bash
# 1. Install dependencies
npm install        # or: bun install / yarn / pnpm

# 2. Start the dev server
npx expo start     # or: bunx expo start / npm run start
```

Then:

- **Phone**: scan the QR code shown in the terminal with the Expo Go app
  (Android: scan from the app; iOS: scan with the Camera app).
- **iOS simulator**: press `i` in the terminal (requires macOS + Xcode).
- **Android emulator**: press `a` in the terminal (requires Android Studio).

Useful checks while developing:

```bash
npm run typecheck   # TypeScript, strict mode
npm run lint        # ESLint (expo lint)
```

## Project structure

```
positive-mindset/
├─ app.json                        # Expo config (name, icons, splash, router)
├─ src/
│  ├─ app/                         # expo-router file-based routes
│  │  ├─ _layout.tsx               #   Root stack + ThemeProvider + FavoritesProvider
│  │  ├─ (tabs)/
│  │  │  ├─ _layout.tsx            #   Bottom tabs: Home + Favorites + Settings
│  │  │  ├─ index.tsx              #   "Choose a Topic" screen
│  │  │  ├─ favorites.tsx          #   Favorites list + empty state
│  │  │  └─ settings.tsx           #   Appearance: Light / Dark / System
│  │  └─ affirmation/[topicId].tsx #   Affirmation screen (Next, heart)
│  ├─ components/
│  │  ├─ TopicCard.tsx             #   Colored topic card on Home
│  │  ├─ FavoriteCard.tsx          #   Card in the Favorites list
│  │  ├─ HeartButton.tsx           #   Favorite toggle (heart icon)
│  │  └─ FadeInView.tsx            #   Small fade transition helper
│  ├─ context/
│  │  ├─ FavoritesContext.tsx      #   Favorites state + persistence
│  │  └─ ThemeContext.tsx          #   Appearance mode + resolved theme
│  ├─ data/affirmations.json       #   Official sample data (30 affirmations)
│  └─ lib/
│     ├─ affirmations.ts           #   Data access + topic filtering
│     ├─ favorites-storage.ts      #   AsyncStorage read/write helpers
│     ├─ theme-preference.ts       #   AsyncStorage read/write for the theme mode
│     ├─ topics.ts                 #   Topic definitions (colors, icons, gradients)
│     ├─ theme.ts                  #   Design tokens (light + dark palettes, fonts)
│     └─ types.ts                  #   Shared types
```

## How it works

- **Data** — `src/data/affirmations.json` is the official assessment sample data file
  (`Tusk_and_Dot_Mobile_Assessment_Sample_Data.json`), copied verbatim — an array of
  `{ id, text, topic }` with 30 items (10 per topic). `src/lib/affirmations.ts` loads it
  and filters by topic name. Topic names in the data (`Confidence`, `Calm`, `Motivation`)
  match the topics defined in `src/lib/topics.ts`.
- **Navigation** — expo-router file-based routing. Home and Favorites are bottom tabs;
  the affirmation screen is a stack screen pushed as `/affirmation/[topicId]`, so it shows
  full-screen without the tab bar. Opening a favorite passes `?id=<AFF-ID>` so the screen
  starts on that affirmation.
- **Next** — the affirmation screen keeps an index into the topic's affirmations and
  advances it with wraparound (`(index + 1) % length`).
- **Favorites persistence** — a React context (`FavoritesContext`) holds the list of
  favorite IDs. On launch it reads them from AsyncStorage under the key
  `@positive-mindset/favorites` (a JSON array of IDs) and saves on every change.
  Storing IDs (not text) keeps favorites stable, and any stored ID that no longer exists
  in the data file is filtered out safely on load.
- **Theme (Light / Dark / System)** — `ThemeContext` holds the saved mode, read from
  AsyncStorage under the key `@positive-mindset/theme-mode`. `system` follows the OS
  appearance (`useColorScheme`), and the resolved theme swaps every screen's palette —
  including dark per-topic gradients on the affirmation screen. The choice is saved
  immediately when picked and restored on the next launch.

## Design notes

- The UI follows the provided design reference: warm cream background, deep forest-green
  primary, pastel topic cards, serif quotes, and per-topic gradient affirmation screens.
  Dark mode mirrors it with a deep forest-charcoal background, lifted surfaces, and
  darker per-topic gradients, while the pastel topic cards keep their fixed tint so
  they stay readable in both themes.
- The serif look uses the platform system serif (Georgia on iOS, `serif` on Android),
  so no font files need to be bundled.
- The `web` platform config exists so the app can also be previewed in a browser during
  development (`npx expo start --web`); the assessment targets are iOS/Android.

## Assumptions & known limitations

- The official sample data file was not attached when the app was first built, so an
  interim dataset was used during development; it has since been fully replaced by the
  official `Tusk_and_Dot_Mobile_Assessment_Sample_Data.json`, copied byte-for-byte into
  `src/data/affirmations.json` (all 30 IDs, topic names, and affirmation text unchanged).
- **Next ordering** — affirmations advance in data order and wrap around; they are not
  shuffled.
- English only — matching the design reference and the strict scope.
- Favorites and the appearance preference use
  `@react-native-async-storage/async-storage`; data is kept only on-device.
- Settings are intentionally minimal: a single Appearance section (Light / Dark /
  System) as requested — no other options were added.
- Per the assessment's strict scope ("no onboarding or extra features"), the welcome
  screen shown in the design reference was intentionally left out; the app opens
  directly on topic selection.
