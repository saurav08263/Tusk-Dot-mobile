import { ActivityIndicator, FlatList, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Ionicons from '@expo/vector-icons/Ionicons';
import { FavoriteCard } from '../../components/FavoriteCard';
import { useFavorites } from '../../context/FavoritesContext';
import { useTheme } from '../../context/ThemeContext';
import { serif } from '../../lib/theme';

export default function FavoritesScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { favoriteAffirmations, isLoaded, toggleFavorite } = useFavorites();
  const { colors } = useTheme();

  return (
    <View style={[styles.screen, { backgroundColor: colors.background, paddingTop: insets.top + 12 }]}>
      <View style={styles.header}>
        <Text style={[styles.title, { color: colors.ink }]}>Favorites</Text>
        <Ionicons name="heart" size={24} color={colors.primary} />
      </View>

      {!isLoaded ? (
        // Avoid flashing the empty state while AsyncStorage is being read.
        <View style={styles.center}>
          <ActivityIndicator color={colors.primary} />
        </View>
      ) : favoriteAffirmations.length === 0 ? (
        <View style={styles.center}>
          <View style={[styles.emptyIconWrap, { backgroundColor: colors.primarySoft }]}>
            <Ionicons name="heart-outline" size={34} color={colors.primary} />
          </View>
          <Text style={[styles.emptyTitle, { color: colors.ink }]}>No favorites yet</Text>
          <Text style={[styles.emptySubtitle, { color: colors.muted }]}>
            Save affirmations you love and find them here.
          </Text>
        </View>
      ) : (
        <FlatList
          data={favoriteAffirmations}
          keyExtractor={(item) => item.id}
          contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 96 }]}
          renderItem={({ item }) => (
            <FavoriteCard
              affirmation={item}
              onToggleFavorite={() => toggleFavorite(item.id)}
              onPress={() => router.push(`/affirmation/${item.topic}?id=${item.id}`)}
            />
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 18,
  },
  title: { fontFamily: serif, fontSize: 30, fontWeight: '700' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  emptyIconWrap: {
    width: 72,
    height: 72,
    borderRadius: 36,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  emptyTitle: { fontFamily: serif, fontSize: 20, fontWeight: '700' },
  emptySubtitle: {
    fontSize: 14,
    lineHeight: 20,
    textAlign: 'center',
    marginTop: 6,
    paddingHorizontal: 32,
  },
  list: { paddingHorizontal: 20, gap: 12 },
});
