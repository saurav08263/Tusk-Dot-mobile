import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { TopicCard } from '../../components/TopicCard';
import { useTheme } from '../../context/ThemeContext';
import { getAffirmationsForTopic } from '../../lib/affirmations';
import { topics } from '../../lib/topics';
import { serif } from '../../lib/theme';

export default function TopicsScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();

  return (
    <View style={[styles.screen, { backgroundColor: colors.background, paddingTop: insets.top + 12 }]}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <MaterialCommunityIcons name="sprout" size={40} color={colors.primary} />
        <Text style={[styles.title, { color: colors.ink }]}>Choose a Topic</Text>
        <Text style={[styles.subtitle, { color: colors.muted }]}>
          Pick a topic that feels right for you today.
        </Text>
        <View style={styles.cards}>
          {topics.map((topic) => (
            <TopicCard
              key={topic.name}
              topic={topic}
              count={getAffirmationsForTopic(topic.name).length}
              onPress={() => router.push(`/affirmation/${topic.name}`)}
            />
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { padding: 20, paddingBottom: 32 },
  title: {
    fontFamily: serif,
    fontSize: 30,
    lineHeight: 38,
    fontWeight: '700',
    marginTop: 10,
  },
  subtitle: { fontSize: 15, lineHeight: 21, marginBottom: 22 },
  cards: { gap: 14 },
});
