import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import type { ComponentProps } from 'react';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useTheme } from '../../context/ThemeContext';
import type { ThemeMode } from '../../lib/theme';
import { serif } from '../../lib/theme';

interface AppearanceOption {
  mode: ThemeMode;
  label: string;
  description: string;
  icon: ComponentProps<typeof Ionicons>['name'];
}

const APPEARANCE_OPTIONS: AppearanceOption[] = [
  {
    mode: 'light',
    label: 'Light',
    description: 'Warm cream look for daytime.',
    icon: 'sunny-outline',
  },
  {
    mode: 'dark',
    label: 'Dark',
    description: 'Easy on the eyes at night.',
    icon: 'moon-outline',
  },
  {
    mode: 'system',
    label: 'System',
    description: 'Match your device setting.',
    icon: 'phone-portrait-outline',
  },
];

export default function SettingsScreen() {
  const insets = useSafeAreaInsets();
  const { mode, setMode, colors } = useTheme();

  return (
    <View style={[styles.screen, { backgroundColor: colors.background, paddingTop: insets.top + 12 }]}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={[styles.title, { color: colors.ink }]}>Settings</Text>

        <Text style={[styles.sectionLabel, { color: colors.muted }]}>APPEARANCE</Text>
        <View style={[styles.group, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          {APPEARANCE_OPTIONS.map((option, index) => {
            const selected = mode === option.mode;
            return (
              <Pressable
                key={option.mode}
                accessibilityRole="radio"
                accessibilityLabel={`${option.label} appearance`}
                aria-checked={selected}
                onPress={() => setMode(option.mode)}
                style={({ pressed }) => [
                  styles.row,
                  index < APPEARANCE_OPTIONS.length - 1 && {
                    borderBottomWidth: StyleSheet.hairlineWidth,
                    borderBottomColor: colors.border,
                  },
                  pressed && styles.pressed,
                ]}
              >
                <View
                  style={[
                    styles.iconWrap,
                    { backgroundColor: selected ? colors.primarySoft : colors.background },
                  ]}
                >
                  <Ionicons
                    name={option.icon}
                    size={20}
                    color={selected ? colors.primary : colors.muted}
                  />
                </View>
                <View style={styles.textWrap}>
                  <Text style={[styles.rowLabel, { color: colors.ink }]}>{option.label}</Text>
                  <Text style={[styles.rowDescription, { color: colors.muted }]}>
                    {option.description}
                  </Text>
                </View>
                <View
                  style={[
                    styles.radio,
                    { borderColor: selected ? colors.primary : colors.border },
                  ]}
                >
                  {selected && <View style={[styles.radioDot, { backgroundColor: colors.primary }]} />}
                </View>
              </Pressable>
            );
          })}
        </View>
        <Text style={[styles.caption, { color: colors.muted }]}>
          Your choice is saved on this device and applied everywhere in the app.
        </Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { padding: 20, paddingBottom: 32 },
  title: {
    fontFamily: serif,
    fontSize: 30,
    lineHeight: 38,
    fontWeight: '700',
    marginBottom: 22,
  },
  sectionLabel: { fontSize: 12, fontWeight: '700', letterSpacing: 1, marginBottom: 10 },
  group: {
    borderRadius: 18,
    borderWidth: StyleSheet.hairlineWidth,
    overflow: 'hidden',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    padding: 16,
  },
  pressed: { opacity: 0.7 },
  iconWrap: {
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textWrap: { flex: 1, gap: 2 },
  rowLabel: { fontSize: 16, fontWeight: '600' },
  rowDescription: { fontSize: 13, lineHeight: 18 },
  radio: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioDot: { width: 10, height: 10, borderRadius: 5 },
  caption: { fontSize: 13, lineHeight: 18, marginTop: 12, paddingHorizontal: 4 },
});
