import { useState } from 'react';
import { Stack, usePathname } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { View } from 'react-native';
import { Welcome } from '../components/Welcome';
import { FavoritesProvider } from '../context/FavoritesContext';
import { ThemeProvider, useTheme } from '../context/ThemeContext';

/** Stack + status bar + welcome overlay, re-rendered when the theme changes. */
function RootNavigator() {
  const { colors, isDark } = useTheme();
  const pathname = usePathname();
  const [showWelcome, setShowWelcome] = useState(true);

  // The welcome screen appears on a cold start at the app root. Deep links
  // (e.g. opening a favorite directly) skip it and land on their screen.
  const isLandingPath = !pathname || pathname === '/' || pathname === '/(tabs)';

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      <Stack
        screenOptions={{
          headerShown: false,
          contentStyle: { backgroundColor: colors.background },
        }}
      />
      {showWelcome && isLandingPath ? (
        <Welcome onGetStarted={() => setShowWelcome(false)} />
      ) : null}
    </View>
  );
}

export default function RootLayout() {
  return (
    <ThemeProvider>
      <FavoritesProvider>
        <RootNavigator />
      </FavoritesProvider>
    </ThemeProvider>
  );
}
