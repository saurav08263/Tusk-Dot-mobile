import { Platform } from 'react-native';

/** Appearance options the user can pick in Settings. */
export type ThemeMode = 'light' | 'dark' | 'system';

/** The concrete theme actually applied to the UI (system resolves to one of these). */
export type ResolvedTheme = 'light' | 'dark';

/** Design tokens shared by every screen. */
export interface Palette {
  background: string;
  surface: string;
  ink: string;
  muted: string;
  primary: string;
  primarySoft: string;
  heart: string;
  border: string;
  onPrimary: string;
  /** Text and icons drawn on top of a topic gradient. */
  onGradient: string;
  /** Softer text drawn on top of a topic gradient (e.g. the affirmation id). */
  onGradientMuted: string;
}

export const palettes: Record<ResolvedTheme, Palette> = {
  light: {
    background: '#F7F2E9',
    surface: '#FFFFFF',
    ink: '#24313C',
    muted: '#7E848B',
    primary: '#2F5D50',
    primarySoft: '#DFEDE4',
    heart: '#E24E4E',
    border: '#ECE5D8',
    onPrimary: '#FFFFFF',
    onGradient: '#24313C',
    onGradientMuted: '#5F6B75',
  },
  dark: {
    background: '#111B16',
    surface: '#1C2A23',
    ink: '#ECF2ED',
    muted: '#9AA8A0',
    primary: '#43816C',
    primarySoft: '#24382F',
    heart: '#F07C7C',
    border: '#2A3B33',
    onPrimary: '#FFFFFF',
    onGradient: '#F2F6F3',
    onGradientMuted: '#A9BBB1',
  },
};

/**
 * Static light palette for components that keep fixed colors on their own
 * tinted surfaces (e.g. the pastel topic cards, which are readable in both
 * themes and therefore do not follow the theme).
 */
export const colors = palettes.light;

/**
 * Platform serif font for headings and quotes.
 * Uses the system serif so no font files need to be bundled.
 */
export const serif = Platform.select({
  ios: 'Georgia',
  android: 'serif',
  default: 'Georgia',
});
