import type { ComponentProps } from 'react';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import type { TopicName } from './types';

export type IconName = ComponentProps<typeof MaterialCommunityIcons>['name'];

export interface Topic {
  name: TopicName;
  tagline: string;
  icon: IconName;
  /** Pastel card color used on the topic list and favorites chips. */
  cardColor: string;
  /** Accent color for icons and chip text. */
  accentColor: string;
  /** Light gradient shown behind the affirmation screen. */
  gradient: [string, string];
  /** Dark gradient shown behind the affirmation screen in dark mode. */
  gradientDark: [string, string];
}

export const topics: Topic[] = [
  {
    name: 'Confidence',
    tagline: 'Believe in yourself and your abilities.',
    icon: 'terrain',
    cardColor: '#DCE9F8',
    accentColor: '#4C7DB8',
    gradient: ['#A6C8EE', '#E9F3FC'],
    gradientDark: ['#16324C', '#0D1B29'],
  },
  {
    name: 'Calm',
    tagline: 'Find peace in the present moment.',
    icon: 'leaf',
    cardColor: '#DFEEDD',
    accentColor: '#4F7D57',
    gradient: ['#A3C9C0', '#E9F1E8'],
    gradientDark: ['#15352D', '#0C1D18'],
  },
  {
    name: 'Motivation',
    tagline: 'Keep going and make progress.',
    icon: 'weather-sunny',
    cardColor: '#E9E4F8',
    accentColor: '#7A67B8',
    gradient: ['#F2B98C', '#FAE9D2'],
    gradientDark: ['#4A3220', '#211712'],
  },
];

export function getTopic(name: string): Topic | undefined {
  return topics.find((topic) => topic.name === name);
}
