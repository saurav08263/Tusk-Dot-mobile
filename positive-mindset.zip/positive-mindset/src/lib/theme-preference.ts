import AsyncStorage from '@react-native-async-storage/async-storage';
import type { ThemeMode } from './theme';

const THEME_MODE_KEY = '@positive-mindset/theme-mode';

const VALID_MODES: ThemeMode[] = ['light', 'dark', 'system'];

/**
 * Reads the saved appearance preference.
 * Defaults to 'system' when nothing is stored yet or the value is unreadable.
 */
export async function loadThemeMode(): Promise<ThemeMode> {
  try {
    const raw = await AsyncStorage.getItem(THEME_MODE_KEY);
    if (raw && (VALID_MODES as string[]).includes(raw)) {
      return raw as ThemeMode;
    }
    return 'system';
  } catch (error) {
    console.warn('Could not load theme preference:', error);
    return 'system';
  }
}

/** Persists the appearance preference. */
export async function saveThemeMode(mode: ThemeMode): Promise<void> {
  try {
    await AsyncStorage.setItem(THEME_MODE_KEY, mode);
  } catch (error) {
    console.warn('Could not save theme preference:', error);
  }
}
