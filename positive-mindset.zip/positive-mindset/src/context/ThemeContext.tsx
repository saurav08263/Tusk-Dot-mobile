import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import type { ReactNode } from 'react';
import { useColorScheme } from 'react-native';
import { palettes } from '../lib/theme';
import type { Palette, ResolvedTheme, ThemeMode } from '../lib/theme';
import { loadThemeMode, saveThemeMode } from '../lib/theme-preference';

interface ThemeContextValue {
  /** The user's saved preference: light, dark, or follow the device. */
  mode: ThemeMode;
  /** The theme actually applied (system mode resolves via the device setting). */
  resolvedTheme: ResolvedTheme;
  /** Design tokens for the resolved theme. */
  colors: Palette;
  isDark: boolean;
  setMode: (mode: ThemeMode) => void;
}

const ThemeContext = createContext<ThemeContextValue | undefined>(undefined);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const systemScheme = useColorScheme();
  const [mode, setModeState] = useState<ThemeMode>('system');

  // Load the persisted preference once when the app starts.
  useEffect(() => {
    let isActive = true;

    loadThemeMode().then((stored) => {
      if (!isActive) return;
      setModeState(stored);
    });

    return () => {
      isActive = false;
    };
  }, []);

  const setMode = useCallback((next: ThemeMode) => {
    setModeState(next);
    void saveThemeMode(next);
  }, []);

  const resolvedTheme: ResolvedTheme =
    mode === 'system' ? (systemScheme ?? 'light') : mode;

  const value = useMemo<ThemeContextValue>(
    () => ({
      mode,
      resolvedTheme,
      colors: palettes[resolvedTheme],
      isDark: resolvedTheme === 'dark',
      setMode,
    }),
    [mode, resolvedTheme, setMode],
  );

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme(): ThemeContextValue {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used inside a ThemeProvider');
  }
  return context;
}
