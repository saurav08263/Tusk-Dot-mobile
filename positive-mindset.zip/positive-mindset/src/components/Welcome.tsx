import { Pressable, StyleSheet, Text, View } from 'react-native';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { FadeInView } from './FadeInView';
import { useTheme } from '../context/ThemeContext';
import { serif } from '../lib/theme';

interface WelcomeProps {
  onGetStarted: () => void;
}

/**
 * Welcome / splash screen shown on a cold start, matching the design
 * reference: warm background, organic blobs, leaf sprig, serif title,
 * and a rounded "Get Started" button.
 */
export function Welcome({ onGetStarted }: WelcomeProps) {
  const insets = useSafeAreaInsets();
  const { colors, isDark } = useTheme();

  const palette = {
    background: isDark ? '#151210' : '#FAEFE1',
    blobSage: isDark ? '#2C3A31' : '#C9D6BE',
    blobPeach: isDark ? '#3B2C21' : '#F6DAC3',
    leaf: isDark ? '#7FA98B' : '#9DB894',
    button: isDark ? '#43816C' : '#5F8D6D',
  };

  return (
    <View
      style={[
        styles.screen,
        {
          backgroundColor: palette.background,
          paddingTop: insets.top,
          paddingBottom: insets.bottom + 24,
          paddingHorizontal: 32,
        },
      ]}
    >
      {/* Organic background blobs (decorative). */}
      <View
        aria-hidden
        pointerEvents="none"
        style={[styles.blobSage, { backgroundColor: palette.blobSage }]}
      />
      <View
        aria-hidden
        pointerEvents="none"
        style={[styles.blobPeach, { backgroundColor: palette.blobPeach }]}
      />
      <View
        aria-hidden
        pointerEvents="none"
        style={[styles.blobAccent, { backgroundColor: palette.blobSage }]}
      />

      <FadeInView animationKey="welcome" style={styles.center}>
        <MaterialCommunityIcons name="sprout" size={84} color={palette.leaf} />
        <Text style={[styles.title, { color: colors.ink }]}>Positive{'\n'}Affirmations</Text>
        <Text style={[styles.subtitle, { color: colors.muted }]}>
          A little positivity{'\n'}can make a big difference.
        </Text>
      </FadeInView>

      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Get started"
        style={({ pressed }) => [
          styles.button,
          { backgroundColor: palette.button },
          pressed && styles.pressed,
        ]}
        onPress={onGetStarted}
      >
        <Text style={[styles.buttonText, { color: colors.onPrimary }]}>Get Started</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    position: 'absolute',
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    zIndex: 10,
    elevation: 10,
  },
  blobSage: {
    position: 'absolute',
    width: 280,
    height: 280,
    borderRadius: 140,
    top: -90,
    right: -80,
  },
  blobPeach: {
    position: 'absolute',
    width: 330,
    height: 330,
    borderRadius: 165,
    bottom: -130,
    left: -120,
  },
  blobAccent: {
    position: 'absolute',
    width: 150,
    height: 150,
    borderRadius: 75,
    bottom: -55,
    right: -45,
    opacity: 0.55,
  },
  center: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontFamily: serif,
    fontSize: 40,
    lineHeight: 50,
    fontWeight: '600',
    textAlign: 'center',
    marginTop: 22,
  },
  subtitle: {
    fontSize: 16,
    lineHeight: 24,
    textAlign: 'center',
    marginTop: 18,
  },
  button: {
    alignSelf: 'stretch',
    height: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#1D3A31',
    shadowOpacity: 0.18,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 5 },
    elevation: 3,
  },
  pressed: { opacity: 0.9, transform: [{ scale: 0.98 }] },
  buttonText: { fontSize: 17, fontWeight: '700' },
});
